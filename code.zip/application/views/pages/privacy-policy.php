<!DOCTYPE html>
<html>
<style>
  .page-description,
  .page-title
  {
    color: white;
  }

  .page-box
  {
    margin-left: 15%;
    height: 100vh;
    width: 100%;
  }
</style>
<div class="row" >
  <div class="page-box col-xs-10 col-sm-10 col-lg-10" >
    <h1 class="page-title" >How it works</h1>
    <h3 class="page-description" ></h3>
    <!DOCTYPE html>
    <html>
    <style>
      .page-description,
      .page-title
      {
        color: white;
      }

      .page-box
      {
        margin-left: 15%;
        height: 100vh;
      }
    </style>
    <div class="row" >
      <div class="page-box col-xs-10 col-sm-10 col-lg-10" >
        <h1 class="page-title" >Contacts</h1>
        <h3 class="page-description" ></h3>
        <!-- Section: Contact v.1 -->
    <section class="my-5">

      <!-- Section heading -->
      <h2 class="h1-responsive font-weight-bold text-center my-5">Privacy Policy</h2>
      <!-- Section description -->
      <p class="text-center w-responsive mx-auto pb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit.
        Fugit, error amet numquam iure provident voluptate esse quasi, veritatis totam voluptas nostrum quisquam
        eum porro a pariatur veniam.</p>

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-lg-12 ">

          What is a Privacy Policy

          A Privacy Policy is a legal statement that specifies what the business owner does with the personal data collected from users, along with how the data is processed and for what purposes.

          In 1968, Council of Europe did studies on the threat of the Internet expansion as they were concerned with the effects of technology on human rights. This lead to the development of policies that were to be developed to protect personal data.

          This marks the start of what we know now as a “Privacy Policy.” While the name “Privacy Policy” refers to the legal agreement, the concept of privacy and protecting user data is closely related.

          This agreement can also be known under these names:

              Privacy Statement
              Privacy Notice
              Privacy Information
              Privacy Page

          A Privacy Policy can be used for both your website and mobile app if it’s adapted to include the platforms your business operates on.

          The requirements for Privacy Policies may differ from one country to another depending on the legislation. However, most privacy laws identify the following critical points that a business must comply with when dealing with personal data:

              Notice – Data collectors must clearly disclose what they are doing with the personal information from users before collecting it.
              Choice – The companies collecting the data must respect the choices of users on what information they choose to provide.
              Access – Users should be able to view, update or request the removal of personal data collected by the company.
              Security – Companies are entirely responsible for the accuracy and security (keeping it properly away from unauthorized eyes and hands) of the collected personal information.

          Who needs a Privacy Policy

          Any entity (company or individual) that collects or uses personal information from users will need a Privacy Policy.

        </div>
        <!-- Grid column -->

        <!-- Grid column -->

      <!-- Grid row -->

    </section>
    <!-- Section: Contact v.1 -->
      </div>
    </div>


    </div>
</div>
