<div class="footer text-muted bg-light mt-5">
	<div class="container">
		<div class="row">
			<div class="col-lg-5 pt-5 pb-5">
				<a href="index.php"><img src="<?php echo base_url(); ?>assets/images/logo.jpg" class="mb-3 img-fluid"></a>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. .</p>
			</div>
			<div class="col-lg-4 pt-5 pb-5">
				<p class="lead pl-5">Company</p>
				<ul class="navbar-nav pl-5 pt-2">
					<li><a href="register.php#">About</a></li>
					<li><a href="register.php#">Privacy Policy</a></li>
					<li><a href="register.php#">Contact us</a></li>
					<li><a href="register.php#">How its Work</a></li>
				</ul>
			</div>
			<div class="col-lg-3 pt-5 pb-5">
				<p class="lead pl-5">Follow Us</p>
				<ul class="navbar-nav pl-5 pt-2">
					<li><a href="register.php#">Facebook</a></li>
					<li><a href="register.php#">Twitter</a></li>
					<li><a href="register.php#">YouTube</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
