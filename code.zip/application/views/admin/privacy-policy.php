<!DOCTYPE html>
<html>
<style>
  .page-description,
  .page-title
  {
    color: white;
  }

  .page-box
  {
    margin-left: 15%;
    height: 100vh;
  }
</style>
<div class="row" >
  <div class="page-box col-xs-10 col-sm-10 col-lg-10" >
    <h1 class="page-title" >Privacy Policy</h1>
    <h3 class="page-description" ></h3>
  </div>
</div>
