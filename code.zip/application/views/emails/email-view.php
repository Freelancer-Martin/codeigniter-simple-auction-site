<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<?php
		$this->load->helper('url');
		//$this->load->model('Users_Create_DB_and_Table');

	?>
	<title>Rpa24 | login</title>

	<title>User Registration Script in CodeIgniter</title>
	<!-- Optional theme -->
	<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">

	<link rel="stylesheet" href="<?php //echo base_url(); ?>assets/styles.css" >
	<script   src="https://code.jquery.com/jquery-3.1.1.js" ></script>
	<!-- Latest compiled and minified JavaScript -->

	<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>

</head>

<?php
